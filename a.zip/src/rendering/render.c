#include "render.h"
#include "../simulation/grid.h"
#include <string.h>

void render_text(const char* text, int x, int y, SDL_Color color, 
                SDL_Renderer* renderer, TTF_Font* font) {
    SDL_Surface* surface = TTF_RenderText_Blended(font, text, color);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect dst = {x, y, surface->w, surface->h};
    SDL_RenderCopy(renderer, texture, NULL, &dst);
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

void render_simulation(SDL_Renderer* renderer, SDL_Renderer* stats_renderer, TTF_Font* font) {
    // Отрисовка основного окна
    if (mutation_fx_counter > 0) {
        mutation_fx_counter--;
        SDL_SetRenderDrawColor(renderer, 255, 255, 50, 255);
        SDL_RenderClear(renderer);
    } else {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
    }

    pthread_mutex_lock(&grid_mutex);
    // ... остальная логика отрисовки ...
    pthread_mutex_unlock(&grid_mutex);
    
    SDL_RenderPresent(renderer);
    rendering_complete = 1;

    // Отрисовка окна статистики
    render_stats_window(stats_renderer, font);
}